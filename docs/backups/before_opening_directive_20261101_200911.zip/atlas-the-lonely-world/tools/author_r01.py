"""Emit editable Godot scene nodes from hand-authored R01 route polygons."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]/'Scene'/'rebuild'
def points(values):
    return ', '.join(str(v) for pair in values for v in pair)

def scene(area, terrain, branches, props, sky):
    lines=['[gd_scene format=3]',f'[node name="R01_A{area:02}" type="Node2D"]']
    def poly(name, vertices, color, collision=False, branch=False):
        lines.extend([f'[node name="{name}" type="'+('StaticBody2D' if collision else 'Node2D')+'" parent="."'+(' groups=["grabbable"]' if collision and not 'Boundary' in name else '')+']'])
        if collision:
            lines.extend(['collision_layer = 2','collision_mask = 0',f'groups = []'] if False else ['collision_layer = 2','collision_mask = 0'])
            # Native nodes are directly editable in the Godot 2D canvas.
            lines.extend([f'[node name="Collision" type="CollisionPolygon2D" parent="{name}"]',f'polygon = PackedVector2Array({points(vertices)})']+(['one_way_collision = true'] if branch else []))
        lines.extend([f'[node name="Surface" type="Polygon2D" parent="{name}"]',f'polygon = PackedVector2Array({points(vertices)})',f'color = Color({color})'])
        if collision:
            lines.extend([f'[node name="TopEdge" type="Line2D" parent="{name}"]',f'points = PackedVector2Array({points(vertices[:-2])})','width = 2.0',f'default_color = Color({"0.76, 0.63, 0.40, 1" if branch else "0.80, 0.84, 0.70, 1"})'])
    poly('Backdrop',[(0,0),(4000,0),(4000,1000),(0,1000)],sky)
    for i,top in enumerate(terrain):
        poly(f'MainRoute_{i:02}',top+[(top[-1][0],950),(top[0][0],950)],'0.39, 0.43, 0.38, 1',True)
    for i,(x,y,w) in enumerate(branches):
        poly(f'Alternative_{i:02}',[(x,y),(x+w,y),(x+w,y+18),(x,y+18)],'0.46, 0.46, 0.36, 1',True,True)
    for i,(x,y,w,h,color) in enumerate(props):
        poly(f'Landmark_{i:02}',[(x,y),(x+w,y),(x+w,y+h),(x,y+h)],color)
    # Foundation edges only at the outer world ends; there are no walls at scene seams.
    if area==1:
        poly('LeftBoundary',[(-25,0),(0,0),(0,950),(-25,950)],'0.2,0.25,0.25,1',True)
    if area==3:
        poly('TemporaryMilestoneBoundary',[(3990,0),(4010,0),(4010,950),(3990,950)],'0.2,0.25,0.25,1',True)
    (ROOT/f'R01_A{area:02}.tscn').write_text('\n\n'.join(lines)+'\n',encoding='utf-8')

scene(1,[[(0,640),(350,640),(600,670),(950,670),(950,644),(1200,644),(1200,616),(1450,616),(1750,640),(2100,640),(2250,670),(2550,670),(2550,640),(2850,640)],[(2905,640),(3150,640),(3300,665),(3550,665),(3800,640),(4000,640)]],[(1000,590,110),(1150,565,140),(1350,590,150),(1900,610,150),(2100,585,140),(2310,610,180),(2820,690,160)],[(60,510,120,130,'0.53,0.43,0.32,1'),(420,535,95,120,'0.55,0.45,0.33,1'),(720,530,90,140,'0.48,0.40,0.30,1'),(1050,505,140,90,'0.3,0.4,0.28,1'),(1750,595,20,45,'0.65,0.56,0.40,1'),(2400,602,22,55,'0.60,0.53,0.40,1')],'0.24,0.32,0.30,1')
scene(2,[[(0,640),(300,640),(500,610),(740,610),(740,580),(940,580),(940,550),(1200,550)],[(1255,550),(1500,550),(1650,520),(1900,520),(2100,500),(2550,500),(2750,520),(2900,550),(3050,580),(3270,580),(3440,610),(3650,640),(4000,640)]],[(1140,610,200),(1330,580,120),(1600,580,150),(1730,550,150),(2000,470,130),(2170,440,220),(2430,470,120),(2670,560,160)],[(2200,330,25,145,'0.42,0.47,0.42,1'),(2440,355,35,140,'0.45,0.48,0.42,1'),(2640,395,70,135,'0.4,0.45,0.40,1'),(3050,430,100,100,'0.31,0.39,0.37,1')],'0.22,0.30,0.30,1')
scene(3,[[(0,640),(500,640),(650,610),(850,610),(850,580),(1100,580),(1250,610),(1400,640),(1650,670),(1900,700),(2200,700)],[(2255,700),(2500,700),(2700,670),(2900,640),(3400,640),(4000,640)]],[(2110,750,240),(2390,725,110),(2570,695,110),(700,640,150)],[(0,380,1200,110,'0.17,0.22,0.23,1'),(1200,450,1000,130,'0.16,0.21,0.23,1'),(2200,470,650,130,'0.17,0.22,0.25,1'),(3500,190,100,320,'0.22,0.29,0.33,1'),(3720,310,240,65,'0.28,0.34,0.37,1')],'0.16,0.22,0.26,1')
